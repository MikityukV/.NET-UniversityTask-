﻿using ProcessingNumber;

namespace GuessTheNumber
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PlayFrom form1 = new PlayFrom();
            LevelGame game = new LevelGame();
            game.LvlGame("Little");
            form1.Show();
            Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            PlayFrom form1 = new PlayFrom();
            LevelGame game = new LevelGame();
            game.LvlGame("Middle");
            form1.Show();
            Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PlayFrom form1 = new PlayFrom();
            LevelGame game = new LevelGame();
            game.LvlGame("Hard");
            form1.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

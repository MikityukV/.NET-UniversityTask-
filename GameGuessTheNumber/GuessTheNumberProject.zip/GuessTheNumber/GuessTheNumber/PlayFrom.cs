﻿using GuessTheNumber;
using ProcessingNumber;


namespace GuessTheNumber
{
   
    public partial class PlayFrom : Form
    {
      
        string num_user;
        public PlayFrom()
        {
            InitializeComponent();
        }
      

        private void Form1_Load(object sender, EventArgs e)
        { LevelGame lvl = new LevelGame();
            label7.Text = lvl.GetLevel();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox2.Text, out int number) || textBox2.Text == "")
            {
                CheckNumber check_num = new CheckNumber();//Create object for checking user num 
                num_user = textBox2.Text;// Read user num from textBox2
                string str = check_num.CheckUserNum(Convert.ToInt32(num_user));//Sent user num to the CheckUserNum method
                label5.Text = str;
            }
            else
            {              
                MessageBox.Show("Enter number.");               
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainForm fr1 = new MainForm();
            fr1.Show();
            Hide();
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
            var myToolTip = new ToolTip();
            myToolTip.SetToolTip(button4, "Click for Tip");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            TipForUser tip = new TipForUser();
            label6.Text = tip.GetTip();
        }
    
    }
}
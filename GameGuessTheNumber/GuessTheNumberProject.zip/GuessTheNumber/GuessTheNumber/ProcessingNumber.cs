﻿namespace ProcessingNumber
{
    
    class LevelGame
    {
       public static string Level { get; set; }

        public int LvlGame(string level)
        {
            RandomNum randomNumObj = new RandomNum();
            LevelGame setLevel = new LevelGame();

            if (level == "Little")
            {
                randomNumObj.CreateRandomNum(1, 11);
                setLevel.SaveLevel("Little");
                return 0;
            }
            else if (level == "Middle")
            {
                randomNumObj.CreateRandomNum(1, 51);
                setLevel.SaveLevel("Middle");
                return 0;
            }
            else
            {
                randomNumObj.CreateRandomNum(1, 101);
                setLevel.SaveLevel("Hard");
                return 0;
            }
        }
        public int SaveLevel(string lvl)
        {
            Level=lvl;
            return 0;
        }
        public string GetLevel()
        {
            return Level.ToString();
        }
    }
   
    
    class RandomNum
    {
        public static int randomNumber { get; private set; }
       
        public void CreateRandomNum(int num1, int num2)
        {
            Random random = new Random();
            randomNumber = random.Next(num1, num2);        
        }
      
    }

    class CheckNumber:RandomNum
    {
        public int checknum { get; set; }

        public string CheckUserNum(int checknum)
        {
           
            if (checknum == randomNumber)
                return "Congratulations! You guessed the number correctly. It's a number: " + randomNumber;
            else if (checknum > randomNumber)
                return "Too high. Try again!";
            else
                return "Too low. Try again!";
            
        }
    }
    class TipForUser:RandomNum
    {

        public string GetTip()
        {
            int a;
            int b;

            LevelGame lvl = new LevelGame();
            string str =  lvl.GetLevel();

            if (str=="Little")
            {
                return "You don't have a tip on this level";
            }

           else
            {
                a = randomNumber - 5;
                b = randomNumber + 5;

                return "The nubmer between " + a + " and " + b;
            }
            
        }
    }
}

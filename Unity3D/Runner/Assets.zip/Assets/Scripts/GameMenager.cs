using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameMenager : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI coinsText;
    [SerializeField] private TextMeshProUGUI countDown;
    private int coinsCount;
    public float countdownDuration = 4f;
    private float currentTime;
    // Start is called before the first frame update
    void Start()
    {
        currentTime = countdownDuration;
        UpdateCountdownText();
        // We start the countdown timer in a separate coroutine
        StartCoroutine(CountdownCoroutine());

    }

    // Update is called once per frame
    void Update()
    {
         
    }
    private void UpdateCountdownText()
    {
        countDown.text = currentTime.ToString("F0"); // Display time without decimal places
    }
    private System.Collections.IEnumerator CountdownCoroutine()
    {
        while (currentTime > 0)
        {
            yield return new WaitForSeconds(1f); // Wait 1 second

            currentTime -= 1f; // do -1 s
            UpdateCountdownText();
        }
        countDown.text = " ";
       
        //countDown.text = "Start";

    }
    public void AddCoin()
    {
        if(currentTime == 0)
        {

            coinsCount++;
            coinsText.text = coinsCount.ToString();
        }
       
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public ParticleSystem glowParticles;
    public float glowDuration = 5f;

    private void Start()
    {
        
        PlayGlowEffect();
    }

    private void PlayGlowEffect()
    {
       
        glowParticles.Play();

        Invoke("StopGlowEffect", glowDuration);
    }

    private void StopGlowEffect()
    {
      
        glowParticles.Stop();
    }
}


using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.UIElements;

public class Tile : MonoBehaviour
{
    public float speed;
    [SerializeField] private List<Transform> points = new List<Transform>();
    [SerializeField] private GameObject coin;
    [SerializeField] private GameObject pills;
    [SerializeField] private float generationDelay = 0.2f;


    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(GenerateObjectWithDelay());
        
    }
    
    private void FixedUpdate()
    {       
        transform.Translate(Vector3.right * speed * Time.fixedDeltaTime);
       
    }
    void ObjGen()
    {
        
        System.Random random = new System.Random(); 
        int randomPointIndex2;

        int randomPointIndex = random.Next(0, points.Count);
        do
        {
            randomPointIndex2 = UnityEngine.Random.Range(0, points.Count);
        } while (randomPointIndex2 == randomPointIndex);

        GameObject newCoin = Instantiate(coin, points[randomPointIndex].position, Quaternion.identity);
     
        GameObject newPills = Instantiate(pills, points[randomPointIndex2].position, Quaternion.identity);
        
        newCoin.transform.SetParent(transform);
        newPills.transform.SetParent(transform);
    }
    // Update is called once per frame
    private IEnumerator GenerateObjectWithDelay()
    {
        yield return new WaitForSeconds(generationDelay);
        
        ObjGen();
       
    }

}

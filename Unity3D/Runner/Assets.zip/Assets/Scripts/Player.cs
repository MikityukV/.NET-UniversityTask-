using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Player : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] private float speed = 5;
    [SerializeField] private CharacterController characterController;

    [SerializeField] private GameObject screendead ;
    public GameObject pl;
    public GameObject AnimDead;

    private AudioSource audioSource;
    public AudioClip collisionSoundMoney; // Sound when you take money
   

    private float timer = 0f; // timer count


    void Start()
    {
        audioSource = GetComponent<AudioSource>(); 
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        characterController.Move(-Vector3.back * speed* Input.GetAxis("Horizontal") * Time.deltaTime); // get a key which u press       
    }
   

    private void OnTriggerEnter(Collider other)

    {
       
        if (other.tag == "Coin")
        {  
            MakeSoundMoney();
        }
       
        
        if (other.tag == "Die" && timer>=5f)
            {
                 pl.SetActive(false);
                AnimDead.SetActive(true);
                Instantiate(AnimDead, transform.position, transform.rotation);
                this.gameObject.SetActive(false);
           
            if (!screendead.activeSelf)
                {
                
                screendead.SetActive(true);
            }
       
           }    
         
 
    }
  
   private void MakeSoundMoney()
        {
            audioSource.PlayOneShot(collisionSoundMoney);
        }  
   
}

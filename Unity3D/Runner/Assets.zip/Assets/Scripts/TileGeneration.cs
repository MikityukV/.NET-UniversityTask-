using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class TileGeneration : MonoBehaviour
{
    [SerializeField] private GameObject tilePrefab;
    [SerializeField] private float speed;
    [SerializeField] private int  maxCount;
    [SerializeField] private List<Tile> tiles = new List<Tile>();
    [SerializeField] private Transform tileHolder;
   
        
    private float newSpeed = 1f;     // ????? ???????? ????? ?????? 30 ??????
    private float timer = 0f; // timer count
    
    // Start is called before the first frame update
    void Start()
    {    
        tiles.First().speed = speed;
        for (int i = 0; i < maxCount; i++)
        {
            GenerateTile();
        }
        
    }
    
    // Update is called once per frame
    private void FixedUpdate()
    {
        List<Tile> sublist = tiles.GetRange(0, maxCount);

        foreach (var m in sublist)
        {
            m.speed = speed;
        }
   
    }
    
    void Update()
    {
       // Invoke("GenerateTile", 300);
        if (tiles.Count < maxCount)
        {
            GenerateTile();
        } 

        timer += Time.deltaTime;

        if (timer >= 10f)
        {
           
            ChangeSpeed(newSpeed);
            timer = 0f;
        }

    }
  
    private void ChangeSpeed(float newSpeed)
    {
        if( speed < 300)
        {
           speed = speed +newSpeed;
        }

    }
   
    private void GenerateTile()
    {
  
        GameObject newTileObj = Instantiate(tilePrefab, tiles.Last().transform.position + Vector3.left * tilePrefab.transform.localScale.x, Quaternion.identity );
        Tile newTile = newTileObj.GetComponent<Tile>();
        newTile.speed = speed;
        tiles.Add(newTile);
        newTileObj.transform.SetParent(tileHolder);
    }

    //delet tile

    private void OnTriggerEnter(Collider other)
    {
        tiles.Remove(other.GetComponent<Tile>());
        Destroy(other.gameObject);

    }
}





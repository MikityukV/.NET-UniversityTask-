﻿namespace GeeksForLessProjectwBD.Models
{
    public class Folders
    {
        public int Id { get; set; }
        public string? name_folder { get; set; }
        public int? parent_child { get; set; }
        
    }
}

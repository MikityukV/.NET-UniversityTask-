﻿using Microsoft.EntityFrameworkCore;

namespace GeeksForLessProjectwBD.Models
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options)
            : base(options)
        { }
        public DbSet<Folders> Folders { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProjectwBD.Controllers
{
    public class CDIController : Controller
    {
        public IActionResult CDIF()
        {
            return View();
        }
    }
}

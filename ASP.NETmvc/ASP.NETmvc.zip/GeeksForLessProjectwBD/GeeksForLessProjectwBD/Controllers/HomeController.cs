﻿using GeeksForLessProjectwBD.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace GeeksForLessProjectwBD.Controllers
{
    public class HomeController : Controller
    {
       
        //create dbContext variable
        private readonly MyDbContext _context;

        public HomeController(MyDbContext dbContext)
        {           
            _context = dbContext;
        }

        public IActionResult Index()
        {
            //fetch data from database table orders
            var orders = _context.Folders.ToList();

            return View(orders);
        }


    }
}
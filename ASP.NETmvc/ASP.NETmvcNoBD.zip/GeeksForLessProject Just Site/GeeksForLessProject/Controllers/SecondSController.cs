﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
    public class SecondSController : Controller
    {
        public IActionResult SecondSF()
        {
            return View();
        }
    }
}

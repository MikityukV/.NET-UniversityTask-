﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
   
    public class ResourceController : Controller
    {
        public IActionResult ResourceF()
        {
            return View();
        }
        
    }
}

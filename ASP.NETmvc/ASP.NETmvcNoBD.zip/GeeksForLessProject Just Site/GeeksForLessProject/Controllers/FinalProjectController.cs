﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
    public class FinalProjectController : Controller
    {
        public IActionResult FinalProjectF()
        {
            return View();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
    public class ProcessController : Controller
    {
        public IActionResult ProcessF()
        {
            return View();
        }
    }
}

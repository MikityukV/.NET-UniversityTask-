﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
    public class PrimarySController : Controller
    {
        public IActionResult PrimarySF()
        {
            return View();
        }
    }
}

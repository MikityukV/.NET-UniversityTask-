﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
    public class EvidenceController : Controller
    {
        public IActionResult EvidenceF()
        {
            return View();
        }
    }
}

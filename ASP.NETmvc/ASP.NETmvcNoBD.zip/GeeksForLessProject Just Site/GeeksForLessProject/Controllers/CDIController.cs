﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
    public class CDIController : Controller
    {
        public IActionResult CDIF()
        {
            return View();
        }
    }
}

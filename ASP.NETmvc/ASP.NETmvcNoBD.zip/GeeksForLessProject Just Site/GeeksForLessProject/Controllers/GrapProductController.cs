﻿using Microsoft.AspNetCore.Mvc;

namespace GeeksForLessProject.Controllers
{
    public class GrapProductController : Controller
    {
        public IActionResult GrapProductF()
        {
            return View();
        }
    }
}

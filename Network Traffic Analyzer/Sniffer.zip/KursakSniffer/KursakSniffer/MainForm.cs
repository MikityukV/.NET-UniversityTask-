﻿using KursakSniffer.BaseClass;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Windows.Forms;

namespace KursakSniffer
{
    public partial class MainForm:Form
    {
        /// <summary>
        /// used to rake the underlying packets;
        /// </summary>
        List<Monitor> monitorList = new List<Monitor>();

        /// <summary>
        /// presenting packets;
        /// </summary>
        List<Packet> pList = new List<Packet>();

        /// <summary>
        /// the packets sniffed -- all;
        /// </summary>
        List<Packet> allList = new List<Packet>();

        /// <summary>
        /// used to refresh the packets sniffed and listView and all the related info;
        /// </summary>
        /// <param name="p"></param>
        delegate void refresh(Packet p);

        /// <summary>
        /// total length sniffed so far - isolating the filtered;
        /// </summary>
        long totalLength = 0;

        /// <summary>
        /// the count of the packets sniffed;
        /// </summary>
        long totalCount = 0;

        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// деактивация кнопок при активации поиска;
        /// </summary>
        private void deactivateSearch()
        {
            filterCheckBox.Enabled = false;
            ipTextBox.Enabled = false;
            typeComboBox.Enabled = false;
            startButton.Enabled = false;
            filterButton.Enabled = false;
            allButton.Enabled = false;
        }

        /// <summary>
        /// активация кнопок после активации поиска;
        /// </summary>
        private void activateSearch()
        {
            filterCheckBox.Enabled = true;
            ipTextBox.Enabled = true;
            typeComboBox.Enabled = true;
            startButton.Enabled = true;
            filterButton.Enabled = true;
            allButton.Enabled = true;
        }

        private void startRaking()
        {
            monitorList.Clear();
            IPAddress[] hosts = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
            if (hosts == null || hosts.Length == 0)
            {
                MessageBox.Show("No hosts detected, please check your network!");
            }
            for (int i = 0; i < hosts.Length; i++)
            {
                Monitor monitor = new Monitor(hosts[i]);
                monitor.newPacketEventHandler += new Monitor.NewPacketEventHandler(onNewPacket);
                monitorList.Add(monitor);
            }
            foreach(Monitor monitor in monitorList)
            {
                monitor.start();
            }
        }

        private void onNewPacket(Monitor monitor, Packet p)
        {
            
            this.Invoke(new refresh(onRefresh), p);
            //this.BeginInvoke(new refresh(onRefresh), p);
        }

        private void onRefresh(Packet p)
        {
            //MessageBox.Show(filterCheckBox.Checked.ToString() + filteringPattern);
            if (this.filterCheckBox.Checked)
            {
                string[] conditions = getFilterCondition();
                if (isIPOkay(p, conditions[0]) && isPORTOkay(p, conditions[1])
                    && (conditions[2] == "" || conditions[2] == p.Type))
                {
                    addAndUpdatePackets(p);
                }
            }
            else
            {
                addAndUpdatePackets(p);
            }
            //MessageBox.Show(p.Src_IP);
            if (totalLength < 10 * 1024)
            {
                this.hintLabel.Text = string.Format("Packets received {0}  Total length： [{1} bytes]", totalCount, totalLength);
            }
            else if (totalLength < 10 * 1024 * 1024)
            {
                this.hintLabel.Text = string.Format("Packets received {0}  Total length： [{1} KB]", totalCount, totalLength / 1024);
            }
            else if (totalLength < 1024 * 1024 * 1024)
            {
                this.hintLabel.Text = string.Format("Packets received {0}  Total length： [{1} MB]", totalCount, totalLength / (1024 * 1024));
            }
            else if(totalLength < (long)1024 * 1024 * 1024 * 2)
            {
                this.hintLabel.Text = string.Format("Packets received {0}  Total length： [{1} GB]", totalCount, totalLength / (1024 * 1024 * 1024));
            }
            else
            {
                totalCount = 0;
                totalLength = 0;
                this.listView.Items.Clear();
                this.pList.Clear();
                this.allList.Clear();
                this.hintLabel.Text = string.Format("Packets received {0}  Total length： [{1} bytes]", 0, 0);
            }
        }

        /// <summary>
        /// ip is "" or is equal to p.Src_IP or p.Des_IP;
        /// </summary>
        /// <param name="p"></param>
        /// <param name="ip"></param>
        /// <returns></returns>
        private bool isIPOkay(Packet p, string ip)
        {
            return ip == "" || p.Src_IP == ip || p.Des_IP == ip;
        }

        /// <summary>
        /// port is either "" or is equal to p.Src_PORT or p.Des_PORT;
        /// </summary>
        /// <param name="p"></param>
        /// <param name="port"></param>
        /// <returns></returns>
        private bool isPORTOkay(Packet p, string port)
        {
            return port == "" || p.Src_PORT == port || p.Des_PORT == port;
        }

        /// <summary>
        /// add one packet to pList and the listView;
        /// besides, refresh the totalCount, totalLength and allList globally;
        /// </summary>
        /// <param name="p"></param>
        private void addAndUpdatePackets(Packet p)
        {
            totalCount++;
            totalLength += p.TotalLength;
            allList.Add(p);
            pList.Add(p);
            this.listView.Items.Add(new ListViewItem(new string[] { p.Src_IP, p.Src_PORT,p.Des_IP, p.Des_PORT,
                        p.Type, p.Time, p.TotalLength.ToString()}));
            this.listView.EnsureVisible(listView.Items.Count > 5? listView.Items.Count - 10:listView.Items.Count);
        }

        /// <summary>
        /// stop sniffing the network;
        /// </summary>
        private void stopReceiving()
        {
            foreach (Monitor monitor in monitorList)
            {
                monitor.stop();
            }
        }

        /// <summary>
        /// when not selecting the list item, clear the details of the previous item;
        /// </summary>
       

        /// <summary>
        /// handle the start button event - deactivating filterCheckBox, ipTextBox, typeComboBox, startButton, filterButton and allButton
        /// and start sniffing the local network;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void startButton_Click(object sender, EventArgs e)
        {           
            deactivateSearch();
            startRaking();
        }

        /// <summary>
        /// activating buttons and stop sniffing around;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void stopButton_Click(object sender, EventArgs e)
        {
           
            activateSearch();
            stopReceiving();
        }

        /// <summary>
        /// clear the pList and listView but not the allList;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearButton_Click(object sender, EventArgs e)
        {
            this.listView.Items.Clear();
            pList.Clear();
           
        }


        /// <summary>
        /// when double click the clear button, clear all the status;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearButton_DoubleClick(object sender, System.EventArgs e)
        {
            totalCount = 0;
            totalLength = 0;
            
            this.listView.Items.Clear();
            this.pList.Clear();
            this.allList.Clear();
            this.hintLabel.Text = string.Format("Packets received {0}  Total length： [{1} bytes]", 0, 0);
        }
        /// <summary>
        /// Display all the sniffed packets in listView;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allButton_Click(object sender, EventArgs e)
        {
            this.listView.Items.Clear();
            pList.Clear();
            Packet p;
            for (int i = 0; i < allList.Count; i++)
            {
                p = allList[i];
                pList.Add(p);
                this.listView.Items.Add(new ListViewItem(new string[] { p.Src_IP, p.Src_PORT,p.Des_IP, p.Des_PORT,
                        p.Type, p.Time, p.TotalLength.ToString()}));
            }
            
        }


        private void ipTextBox_GotFocus(object sender, System.EventArgs e)
        {
            ipTextBox.ForeColor = Color.Black;
            ipTextBox.Text = "";
            ipTextBox.GotFocus -= ipTextBox_GotFocus;
        }
        
        /// <summary>
        /// when selecting the list item and present the details at the bottom of the panel;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listView_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListView listView = sender as ListView;
            if (listView.SelectedItems != null && listView.SelectedItems.Count != 0)
            {
                Packet p = pList[listView.SelectedItems[0].Index];
                //MessageBox.Show("charLength:" + p.getCharString().Length + "\n" + "hexLength:" + p.getHexString().Length);
              
            }
        }

        private void filterCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if(this.filterCheckBox.Checked && this.ipTextBox.ForeColor != Color.Black)
            {
                this.ipTextBox.Text = "";
                this.ipTextBox.ForeColor = Color.Black;
            }
        }

        /// <summary>
        /// used to bind the charTextBox and the hexTextBox;
        /// scrolling each of them will scroll the other;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// confirm the app closing event;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainFrom_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure to close the App ?", "Hint", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                e.Cancel = false;  //close it;
            }
            else
            {
                e.Cancel = true;
            }
        }

      
        private void filterButton_Click(object sender, EventArgs e)
        {
            if (this.listView.Items.Count < 1)
            {
                MessageBox.Show("Please sniff or show all the sniffed packets first！");
            }
            showIPPackets(getFilterCondition());
            
        }

        /// <summary>
        /// according to the ipTextBox and typeComboBox get the filter conditions including ip, port and type;
        /// default value "";
        /// </summary>
        /// <returns></returns>
        private string[] getFilterCondition()
        {
            string[] conditions = { "", "", "" };
            string tmpString = this.ipTextBox.Text;
            int port = 0;
            if (this.typeComboBox.SelectedIndex > -1)
                conditions[2] = this.typeComboBox.SelectedItem.ToString();
            if (tmpString.Contains('/') || tmpString.Contains(':'))//IP:PORT OR IP/PORT
            {
                string[] arr = { null, null };
                if (tmpString.Contains('/'))
                    arr = tmpString.Split(new char[] { '/' });
                else
                    arr = tmpString.Split(new char[] { ':' });
                conditions[0] = arr[0];
                conditions[1] = arr[1];
            }
            else if (int.TryParse(tmpString, out port))//just port;
                conditions[1] = port.ToString();
            else//just IP;
                conditions[0] = tmpString;
            //Console.WriteLine(conditions);
            return conditions;
        }

        private void showIPPackets(string[] conditions)
        {
            string ipString = conditions[0];
            string port = conditions[1];
            string type = conditions[2];
            Packet p;
            this.listView.Items.Clear();
            pList.Clear();
            for(int i = 0; i < allList.Count; i++)
            {
                p = allList[i];
                if (isIPOkay(p, conditions[0]) && isPORTOkay(p, conditions[1])
                    && (conditions[2] == "" || conditions[2] == p.Type))
                {
                    pList.Add(p);
                    this.listView.Items.Add(new ListViewItem(new string[] { p.Src_IP, p.Src_PORT,p.Des_IP, p.Des_PORT,
                        p.Type, p.Time, p.TotalLength.ToString()}));
                }
            }
        }

        
        /// <summary>
        /// forbid the user to adjust the width of the listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listView_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
        {
            e.Cancel = true;
            e.NewWidth = this.listView.Columns[e.ColumnIndex].Width;
        }
    }
}

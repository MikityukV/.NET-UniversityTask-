﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;


namespace KursakSniffer.BaseClass
{
    class Monitor
    {
              
        private const int IOC_VENDOR = 0x18000000; // входит в сумму SIO_RCVALL 
        private const int IOC_IN = -2147483648; //0x80000000; ВХОДИТ В сумму SIO_RCVALL 
        private const int SIO_RCVALL = IOC_IN | IOC_VENDOR | 1; // SIO_RCVALL равен  0x98000001 он указывает принимать все IP пакеты  18000000+80000000+1= 
        private const int BUF_SIZE = 1024 * 1024;


        private Socket monitor_Socket;
        private IPAddress ipAddress;
        private byte[] buffer;

        public Monitor(IPAddress ip) 
        {
            this.ipAddress = ip;
			this.buffer = new byte[BUF_SIZE];
		}
		
        public void start()
        {
            if (monitor_Socket == null)
            {
                try
                {
                    
                    if (ipAddress.AddressFamily == AddressFamily.InterNetwork)
                    {
                        monitor_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Raw, System.Net.Sockets.ProtocolType.IP);
                    }
                    else
                    {
                        monitor_Socket = new Socket(AddressFamily.InterNetworkV6, SocketType.Raw, System.Net.Sockets.ProtocolType.IP);
                    }
                    monitor_Socket.Bind(new IPEndPoint(ipAddress, 0)); // привязка IP адреса для получения сообщений, отправок и вообще работы 
                    monitor_Socket.IOControl(SIO_RCVALL, BitConverter.GetBytes((int)1), null);
                    monitor_Socket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(this.OnReceive), null);
                }
                catch(Exception e)
                {
                    monitor_Socket.Close();
                    monitor_Socket = null;
                    Console.WriteLine(e.ToString());
                }
            }
        }

        public void stop()
        {
            if(monitor_Socket != null)
            {
                monitor_Socket.Close();
                monitor_Socket = null;
            }
        }

        private void OnReceive(IAsyncResult rs)
        {
            try
            {
                int len = monitor_Socket.EndReceive(rs); // делегат ассинхронного режима должен иметь begin и end 
                if (monitor_Socket != null)
                {
                    byte[] receivedBuffer = new byte[len];
                    Array.Copy(buffer, 0, receivedBuffer, 0, len);
                    try
                    {
                        Packet packet = new Packet(receivedBuffer);
                        NewPacket(packet);
                    }
                    catch (ArgumentNullException nl)
                    {
                        Console.WriteLine(nl.ToString());
                    }
                    catch (ArgumentException ae)
                    {
                        Console.WriteLine(ae.ToString());
                    }
                }
                monitor_Socket.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(this.OnReceive), null);
            }
            catch
            {
                stop();
            }
        }
        public event NewPacketEventHandler newPacketEventHandler;
        public delegate void NewPacketEventHandler(Monitor monitor, Packet p);

        protected void NewPacket(Packet p)
        {
            if (newPacketEventHandler != null)
            {
                newPacketEventHandler(this, p);
            }
        }
    
    }
}

//удалила ~Monitor ( strop)
// удалила dll Библиотеки  заменила ar на rs
// удалила  private const int SECURITY_BUILTIN_DOMAIN_RID = 0x20;
//private const int DOMAIN_ALIAS_RID_ADMINS = 0x220;
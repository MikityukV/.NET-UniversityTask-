﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KursakSniffer.BaseClass
{
    class MyRichTextBox:RichTextBox
    {
        [DllImport("user32.dll")]  
        public static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);  
        public MyRichTextBox()  
        {  
        }  
        public const int WM_HSCROLL = 276;  
        public const int WM_VSCROLL = 277;  
        public const int WM_SETCURSOR = 32;  
        public const int WM_MOUSEWHEEL = 522;  
        public const int WM_MOUSEMOVE = 512;  
        public const int WM_MOUSELEAVE = 675;  
        public const int WM_MOUSELAST = 521;  
        public const int WM_MOUSEHOVER = 673;  
        public const int WM_MOUSEFIRST = 512;  
        public const int WM_MOUSEACTIVATE = 33;  
       
    }
}
// просто отслеживаю самостоятельно мышку вне проги
